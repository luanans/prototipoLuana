//
//  PopUpViewController.swift
//  prototipoLuana
//
//  Created by Aluno on 4/6/18.
//  Copyright © 2018 Aluno. All rights reserved.
//

import UIKit

class PopUpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func ClosePopUp(_ sender: Any) {
        self.view.removeFromSuperview()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
